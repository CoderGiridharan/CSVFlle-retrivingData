package com.samco.FileUploadInSpringBoot.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.samco.FileUploadInSpringBoot.model.Student;
import com.samco.FileUploadInSpringBoot.model.StudentRepository;
import com.univocity.parsers.common.record.Record;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;


@RestController
public class StudentController {
	
	@Autowired
	StudentRepository studentRepository;

	@PostMapping("/upload") 
	public String uploadeData(@RequestParam("file") MultipartFile file) throws Exception{
		List<Student> studentList = new ArrayList<>();	
		InputStream inputStream= file.getInputStream();
		CsvParserSettings setting = new CsvParserSettings();
		setting.setHeaderExtractionEnabled(true);
		CsvParser parser = new CsvParser(setting);
		List<Record> parseAllRecords = parser.parseAllRecords(inputStream);
		parseAllRecords.forEach(record ->{
			Student student = new Student();
			student.setId(Integer.parseInt(record.getString("id")));
			student.setRollno(record.getString("rollno"));
			student.setRegno(record.getString("registernumber"));
			student.setName(record.getString("name"));
			student.setDepartment(record.getString("department"));
			studentList.add(student);
		});
		studentRepository.saveAll(studentList);
		return "upload success !!";
	}
	
	@GetMapping("/getStudent")
	public List<Student> getStudent(){
		return studentRepository.findAll();
	
	}
	
	@GetMapping("/getStudent/{id}")
	public Optional<Student> getStudentById(@PathVariable("id")int id){
		return studentRepository.findById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable int  id) {
		studentRepository.deleteById(id);
	}
	
	
	
}
