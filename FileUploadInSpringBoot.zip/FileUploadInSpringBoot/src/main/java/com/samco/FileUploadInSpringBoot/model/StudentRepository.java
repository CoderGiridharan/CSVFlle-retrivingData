package com.samco.FileUploadInSpringBoot.model;


import org.springframework.data.mongodb.repository.MongoRepository;


public interface StudentRepository extends MongoRepository<Student, Integer>{
	
}
